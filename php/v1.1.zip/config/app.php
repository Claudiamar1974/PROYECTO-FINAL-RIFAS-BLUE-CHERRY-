<?php
// Configuración de la aplicación
// Duración por defecto de una reserva en minutos
if (!defined('RESERVA_MINUTOS')) {
    // Cambiado a 5 minutos por petición
    define('RESERVA_MINUTOS', 5);
}

?>