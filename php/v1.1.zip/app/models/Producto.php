<?php
// Modelo de producto (ejemplo)
class Producto {
    // Propiedades y métodos del producto
}
