<?php
// Controlador de la página principal
class HomeController {
    public function index() {
        // Lógica para mostrar la página principal
        require '../app/views/home/index.php';
    }
}
