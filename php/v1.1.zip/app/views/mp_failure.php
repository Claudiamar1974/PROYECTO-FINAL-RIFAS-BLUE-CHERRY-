<h2>Pago fallido</h2>
<p>El pago fue rechazado o cancelado.</p>
<a href="index.php">Volver al inicio</a>