<h2>Pago pendiente</h2>
<p>El pago está pendiente de aprobación.</p>
<a href="index.php">Volver al inicio</a>