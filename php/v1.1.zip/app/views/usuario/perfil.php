<?php
// Perfil: redirige al controlador principal de usuario (r=usuario)
header('Location: /public/index.php?r=usuario');
exit;