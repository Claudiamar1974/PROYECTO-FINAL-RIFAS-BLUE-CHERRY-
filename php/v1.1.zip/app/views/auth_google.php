<?php
// Este archivo queda vacío intencionalmente: la UI de login se maneja desde el partial header.php (navbar)
// Mantener el include por compatibilidad con public/index.php

