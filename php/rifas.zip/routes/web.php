<?php

use Illuminate\Support\Facades\Route;
use Laravel\Socialite\Facades\Socialite;
use App\Models\Usuario;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Ruta principal
Route::get('/', function () {
    return view('welcome'); // resources/views/welcome.blade.php
});

// Login con Google
Route::get('/login/google', function () {
    return Socialite::driver('google')->redirect();
})->name('login.google');

// Callback de Google
Route::get('/login/google/callback', function () {
    $googleUser = Socialite::driver('google')->stateless()->user();

    // Guardar o actualizar usuario en la tabla 'usuarios'
    $usuario = Usuario::updateOrCreate(
        ['google_id' => $googleUser->getId()],
        [
            'nombre' => $googleUser->getName(),
            'email' => $googleUser->getEmail(),
            'avatar' => $googleUser->getAvatar(),
        ]
    );

    // Loguear al usuario
    Auth::login($usuario);

    return redirect('/');
});

// Ruta para cerrar sesión
Route::post('/logout', function () {
    Auth::logout();
    return redirect('/');
})->name('logout');
