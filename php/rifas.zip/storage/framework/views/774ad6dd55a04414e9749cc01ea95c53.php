<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rifas Solidarias</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #121212; /* Fondo negro */
            color: #ffffff; /* Texto por defecto blanco */
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Segoe UI', sans-serif;
        }
        .card {
            background-color: #1e1e1e; /* Tarjeta oscura */
            border: 2px solid #f1c40f; /* Borde dorado */
            border-radius: 1rem;
            padding: 2rem;
            text-align: center;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 0 20px rgba(241, 196, 15, 0.4);
        }
        .card h1, .card p {
            color: #ffffff; /* Texto blanco */
        }
        .btn-google {
            background-color: #f1c40f;
            color: #1e1e1e;
            font-weight: bold;
            transition: 0.3s;
        }
        .btn-google:hover {
            background-color: #d4ac0d;
            color: #fff;
        }
        .btn-logout {
            background-color: #f1c40f;
            color: #1e1e1e;
            font-weight: bold;
            transition: 0.3s;
        }
        .btn-logout:hover {
            background-color: #d4ac0d;
            color: #fff;
        }
        .logo {
            width: 80px;
            margin-bottom: 1rem;
        }
        img.avatar {
            border-radius: 50%;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="card">
        <img src="https://img.icons8.com/color/96/google-logo.png" alt="Google Logo" class="logo">
        <h1 class="mb-3">Rifas Solidarias</h1>
        <p class="mb-4">Inicia sesión con tu cuenta de Google para participar y crear rifas solidarias.</p>

       <?php if(auth()->check()): ?>
    <p>Hola, <?php echo e(auth()->user()->nombre); ?></p>
    <img src="<?php echo e(auth()->user()->avatar); ?>" alt="Avatar" class="avatar" width="80">

    <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-logout btn-lg w-100">Cerrar sesión</button>
    </form>
<?php else: ?>
    <a href="<?php echo e(route('login.google')); ?>" class="btn btn-google btn-lg w-100">
        <i class="bi bi-google"></i> Iniciar sesión con Google
    </a>
<?php endif; ?>

    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp_8.2\htdocs\rifas\resources\views/welcome.blade.php ENDPATH**/ ?>